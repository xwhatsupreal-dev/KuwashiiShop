const AdmZip = require("adm-zip");
const fs = require("fs");
const path = require("path");

const zip = new AdmZip();

// Function to recursively add files
function addFolderToZip(folderPath, zipPath) {
  const files = fs.readdirSync(folderPath);
  for (const file of files) {
    const fullPath = path.join(folderPath, file);
    if (file === "node_modules" || file === "dist" || file === ".git" || file.endsWith(".zip") || file.endsWith(".tar.gz")) {
      continue; // Skip
    }
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      addFolderToZip(fullPath, path.join(zipPath, file));
    } else {
      zip.addLocalFile(fullPath, zipPath);
    }
  }
}

addFolderToZip(__dirname, "");
zip.writeZip(path.join(__dirname, "public", "KuwashiiShopApp.zip"));
console.log("Zip created!");
